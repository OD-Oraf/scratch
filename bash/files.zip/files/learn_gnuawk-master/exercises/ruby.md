# Introduction

REPL is a good way to learn RUBY for beginners.

```ruby
>> 3 + 7
=> 10
>> 22 / 7
=> 3
>> 22.0 / 7
=> 3.142857142857143
```

## String methods

ruby comes loaded with awesome methods. Enjoy learning RuBy.

```ruby
>> 'ruby'.capitalize
=> "Ruby"

>> ' comma  '.strip
=> "comma"
```

